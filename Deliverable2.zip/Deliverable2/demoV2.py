###########################################################
#MAZE GENERATION                                          #
# source: http://www.migapro.com/depth-first-search/      #
# Program uses recursive backtraking to fill in a         #
#Key:                                                     #
#0 = wall(not path)                                       #
#1 = path                                                 #
#2 = start                                                #
#3 = end                                                  #
# maze.                                                   #
###########################################################
import random
import math
from Tkinter import *

def make2dList(rows,cols,fill):
    return [ ([fill] * cols) for row in xrange(rows)]
    
def index2dList(list,item):
    rows = len(list)
    cols = len(list[0])
    for row in xrange(rows):
        for col in xrange(cols):
            if list[row][col] == item:
                return (row,col)
    return None
        


def makeMaze(rows,cols):
    if rows % 2 == 0:
        maze = make2dList(rows,cols,0)
        currentCell = (len(maze)-1,len(maze[0])/2-1)
        maze[currentCell[0]][currentCell[1]] = 1
        recursiveMaze(maze, currentCell)
        # add exit location 
        exitRow = 0
        exitCol = cols / 2
        #marking the start       
        #check cell below it to find path
        while maze[0].count(1) == 0:
            if maze[exitRow+1][exitCol] == 1:
                maze[exitRow][exitCol] = 1
            else:
                exitCol+= 1
     
        return maze
    else:
        return  "must enter even number of rows"
        
def generateRandomDirs():
    dirs = ["North","South","East","West"]
    random.shuffle(dirs)
    return dirs

def recursiveMaze(maze, currentCell):
    dirs = generateRandomDirs()
    (rows, cols) = (len(maze), len(maze[0]))
    (row, col) = currentCell
    for i in xrange(4):
        if (dirs[i] == "North"):
            # Check up
            if (row - 2 <= 0): pass
            elif (maze[row-2][col] == 0):
                # Empty
                maze[row-2][col] = 1
                maze[row-1][col] = 1
                recursiveMaze(maze, (row-2, col))
        elif (dirs[i] == "South"):
            # check down
            if (row + 2 >= rows): pass
            elif (maze[row + 2][col]) == 0:
                maze[row + 2][col] = 1
                maze[row + 1][col] = 1
                recursiveMaze(maze, (row+2,col))
        elif (dirs[i] == "East"):
            # check Right
            if (col -2 <= 0): pass
            elif (maze[row][col - 2]) == 0:
                  maze[row][col -2] = 1
                  maze[row][col -1] = 1
                  recursiveMaze(maze, (row,col-2))
        elif (dirs[i] == "West"):
            # check Left
            if (col + 2 >= cols): pass
            elif (maze[row][col + 2]) == 0:
                  maze[row][col + 2] = 1
                  maze[row][col + 1] = 1
                  recursiveMaze(maze,(row,col +2))

def print2dList(maze):
    if (maze == []):
        # So we don't crash accessing a[0]
        print []
        return
    rows = len(maze)
    cols = len(maze[0])
    fieldWidth = maxItemLength(maze)
    print "[ ",
    for row in xrange(rows):
        if (row > 0): print "\n  ",
        print "[ ",
        for col in xrange(cols):
            if (col > 0): print ",",
            # The next 2 lines print a[row][col] with the given fieldWidth
            format = "%" + str(fieldWidth) + "s"
            print format % str(maze[row][col]),
        print "]",
    print "]"
    
def maxItemLength(a):
    maxLen = 0
    rows = len(a)
    cols = len(a[0])
    for row in xrange(rows):
        for col in xrange(cols):
            maxLen = max(maxLen, len(str(a[row][col])))
    return maxLen
# test for maze gerenation 
#print2dList(makeMaze(10,10))


###########################################################
#Test Draw Maze 
# Displays the maze from a the top. 
# may be implemented as map latter                        #
# Anmiation Class Source:                                 #
#http://www.kosbie.net/cmu/fall-13/15-112/                #
###########################################################

class TestAnimation(object):
    # Override these methods when creating your own animation
    def mousePressed(self, event): pass
    def keyPressed(self, event): pass
    def timerFired(self): pass
    def init(self): pass
    def redrawAll(self): pass
    
    # Call app.run(width,height) to get your app started
    def run(self):
        # create the root and the canvas
        root = Tk()
        self.cellSize = 8
        rows = self.rows
        cols = self.cols 
        cellSize = self.cellSize
        self.width = cols*cellSize
        self.height =   rows*cellSize
        self.canvas = Canvas(root, width=self.width, height=self.height)
        self.canvas.pack()
        # set up events
        def redrawAllWrapper():
            self.canvas.delete(ALL)
            self.redrawAll()
        def mousePressedWrapper(event):
            self.mousePressed(event)
            redrawAllWrapper()
        def keyPressedWrapper(event):
            self.keyPressed(event)
            redrawAllWrapper()
        root.bind("<Button-1>", mousePressedWrapper)
        root.bind("<Key>", keyPressedWrapper)
        # set up timerFired events
        self.timerFiredDelay = 250 # milliseconds
        def timerFiredWrapper():
            self.timerFired()
            redrawAllWrapper()
            # pause, then call timerFired again
            self.canvas.after(self.timerFiredDelay, timerFiredWrapper)
        # init and get timerFired running
        self.init()
        timerFiredWrapper()
        # and launch the app
        root.mainloop()  # This call BLOCKS 

class TestMaze(TestAnimation):
    
    def __init__(self,rows,cols):
        self.rows = rows
        self.cols = cols
        self.maze = self.initMaze(makeMaze(rows,cols))
        
    def initMaze(self,maze):
        startRow = self.rows -1 
        startCol = len(maze[0])/2-1
        maze[startRow][startCol] = 2
        endRow = 0
        endCol = maze[endRow].index(1) 
        maze[endRow][endCol] = 3 
        return maze 

    def redrawAll(self):
        rows = self.rows
        cols = self.cols 
        maze = self.maze
        for row in xrange(rows):
            for col in xrange(cols):
                if maze[row][col] ==1:
                    self.drawTestMazeCell(row,col,"white")
                elif maze[row][col] == 2:
                    self.drawTestMazeCell(row,col,"green")
                elif maze[row][col] == 3:
                    self.drawTestMazeCell(row,col,"red")
                else:
                    self.drawTestMazeCell(row,col,"Black")
                    
    def drawTestMazeCell(self,row,col,color):
            cellSize = self.cellSize
            left =  col * cellSize
            right = left + cellSize
            top =  row * cellSize
            bottom = top + cellSize
            self.canvas.create_rectangle(left, top, right, bottom, fill=str(color))
#Test Here
# may be implemented as map latter          
#testMaze = TestMaze(60,60)
#testMaze.run()     

###########################################################
#Maze Game                                                #
# Anmiation Class Source:                                 #
#http://www.kosbie.net/cmu/fall-13/15-112/                #
###########################################################           
                    
class Animation(object):
    # Override these methods when creating your own animation
    def mousePressed(self, event): pass
    def keyPressed(self, event): pass
    def timerFired(self): pass
    def init(self): pass
    def redrawAll(self): pass
    
    # Call app.run(width,height) to get your app started
    def run(self, width=720, height=576):
        # create the root and the canvas
        root = Tk()
        self.width = width
        self.height = height
        self.canvas = Canvas(root, width=width, height=height)
        self.canvas.pack()
        # set up events
        def redrawAllWrapper():
            self.canvas.delete(ALL)
            self.redrawAll()
        def mousePressedWrapper(event):
            self.mousePressed(event)
            redrawAllWrapper()
        def keyPressedWrapper(event):
            self.keyPressed(event)
            redrawAllWrapper()
        root.bind("<Button-1>", mousePressedWrapper)
        root.bind("<Key>", keyPressedWrapper)
        # set up timerFired events
        self.timerFiredDelay = 250 # milliseconds
        def timerFiredWrapper():
            self.timerFired()
            redrawAllWrapper()
            # pause, then call timerFired again
            self.canvas.after(self.timerFiredDelay, timerFiredWrapper)
        # init and get timerFired running
        self.init()
        timerFiredWrapper()
        # and launch the app
        root.mainloop()  # This call BLOCKS (so your program waits until you close the window!)
# Location of tiles
#        

class Game(Animation):
    def __init__(self,rows,cols,canvasHeight=576,canvasWidth=720):
        self.maze = Maze(rows,cols,canvasHeight,canvasWidth)
        self.rows = rows
        self.cols = cols 
        self.wallSize = 50 
        self.curentCel = None
        self.player = Player(canvasHeight,canvasWidth,self.maze)
        
    def mousePressed(self, event):
        print event.x,event.y
            
    
    def keyPressed(self, event):     
        if event.keysym == "Up":
            self.maze.moveCell("north")
        elif event.keysym == "Down":
            self.maze.moveCell("south")
        elif event.keysym == "Left":
            self.maze.moveCell("west")
        elif event.keysym == "Right":
            self.maze.moveCell("east")
        
             
        
    
    def timerFired(self): 
        self.walls = self.maze.findWalls()
        move = self.player.atWall(self.walls)
        
    
    def redrawAll(self): 
        self.canvas.delete(ALL)
        self.maze.draw(self.canvas,self.wallSize)
        self.player.draw(self.canvas)
        

class Maze(object):
    
    def __init__(self,rows,cols,canvasHeight,canvasWidth):
        self.rows = rows
        self.cols = cols
        self.canvasHeight= canvasHeight 
        self.canvasWidth = canvasWidth 
        self.maze = self.initMaze(makeMaze(rows,cols))


        
    def initMaze(self,maze):
        startRow = self.rows -1 
        startCol = len(maze[0])/2-1
        maze[startRow][startCol] = "player"
        endRow = 0
        endCol = maze[endRow].index(1) 
        maze[endRow][endCol] = "end"
        return maze 
    
    def moveCell(self,dir):
        playerRow = self.playerLocation[0]
        playerCol = self.playerLocation[1]
        walls = self.findWalls()
        if dir not in walls:
            if dir == "north":
                dRow = -1
                dCol = 0
            elif dir == "south":
                dRow = 1
                dCol = 0
            elif dir == "west":
                dRow = 0
                dCol = -1
            elif dir == "east":
                dRow = 0
                dCol = 1
            self.maze[playerRow][playerCol]= 1
            if self.maze[playerRow+dRow][playerCol+dCol] == "end":
                    print "you win"
            self.maze[playerRow+dRow][playerCol+dCol] = "player"
        
        
        
        
    def draw(self,canvas,wallSize =50 ):
        walls = self.findWalls()
        canvas.create_rectangle(0,0,self.canvasWidth,self.canvasHeight,fill ="white")
        self.drawCorner(canvas,wallSize)
        for wall in xrange(len(walls)):
            if walls[wall] == "north":
                left,top,right,bottom = (0,0,self.canvasWidth, wallSize)
            elif walls[wall] == "south":
                left,top,right,bottom = (0,(self.canvasHeight - wallSize),
                                        (self.canvasWidth),(self.canvasHeight))
            elif walls[wall] == "west":
                left,top,right,bottom = (0,0,wallSize,self.canvasHeight)
            elif walls[wall] == "east":
                left,top,right,bottom = ((self.canvasWidth - wallSize),0,
                                         self.canvasWidth, self.canvasHeight)
            canvas.create_rectangle(left,top,right,bottom,fill ="black")
        
    def findWalls(self):
        maze = self.maze
        playerLocation = index2dList(self.maze,"player")
        self.playerLocation = playerLocation 
        startRow= playerLocation[0]
        startCol= playerLocation[1]
        dirs = [(-1,0),(+1,0),(0,+1),(0,-1)]
        dirName = [ "north","south","east","west"]
        rows = self.rows
        cols = self.cols
        wallList = []
        for dir in xrange(len(dirs)):
            (drow,dcol) = dirs[dir]
            newRow = startRow + drow
            newCol = startCol + dcol
            if ((newRow < 0)or(newRow >= rows)or(newCol < 0)or(newCol >= cols) 
                or maze[newRow][newCol] == 0 ):
                wallList.append(dirName[dir])
        #print wallList
        return wallList

    def drawCorner(self,canvas,wallSize = 50):
        canvas.create_rectangle(0,0,wallSize,wallSize,fill = "black")
        canvas.create_rectangle(self.canvasWidth -wallSize,0,self.canvasWidth,
                                wallSize,fill = "black")
        canvas.create_rectangle(0,self.canvasHeight - wallSize,wallSize,
                                self.canvasHeight,fill ="black")
        canvas.create_rectangle(self.canvasWidth -wallSize,
                                self.canvasHeight -wallSize,self.canvasWidth,
                                self.canvasHeight,fill ="black")
            

class Event(Maze):
    pass
    #toDo: Add event tiles to maze, when maze time is evnet type, overided
    # maze Draw         
        
    
    
    
class Player(object):
    def __init__(self,canvasHeight,canvasWidth,maze):
        self.canvasHeight = canvasHeight
        self.canvasWidth = canvasWidth
        self.playerCx = canvasWidth / 2
        self.playerCy = canvasHeight / 2
        self.playerR = 20 
        self.maze = maze
        
    def draw(self,canvas):
        r = self.playerR
        cx = self.playerCx
        cy = self.playerCy
        canvas.create_oval(cx -r,cy-r,cx+r,cy+r,fill = "black")
        
    def move(self,dir):
        if dir == "north":
            self.playerCy += -2
        elif dir == "south":
            self.playerCy += 2
        elif dir == "east":
            self.playerCx +=2
        elif dir =="west":
            self.playerCx += -2
    def atWall(self,walls):
        pass
                    
    def collsion(self,other):
        pass
        #toDo
    def attack(self,other):
        pass
        # toDo 
        
class Invotory(object):
    pass
    #add draw and game logig functions 
    


    
        
        
        
        
        
        
Game(24,24).run()


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        


